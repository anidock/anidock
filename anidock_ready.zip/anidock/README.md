# Anidock
This is the Anidock anime streaming project.